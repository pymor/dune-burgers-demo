/******************************************************************************

  The DUNE (see www.dune-project.org) module dune-spgrid provides a structured,
  parallel grid satisfying the dune-grid interface.

  Copyright (C) 2012 - 2014 Christoph Gersbacher
  Copyright (C) 2010 - 2013 Robert Klöfkorn
  Copyright (C) 2013        Tobias Malkmus
  Copyright (C) 2009 - 2014 Martin Nolte

  The dune-spgrid module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation, either version 2 of 
  the License, or (at your option) any later version.

  The dune-spgrid module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this module. If not, see <http://www.gnu.org/licenses/>.

******************************************************************************/

#ifndef DUNE_GRID_SUPERENTITYITERATOR_HH
#define DUNE_GRID_SUPERENTITYITERATOR_HH

#include <dune/grid/common/entityiterator.hh>

/** \file
 *  \author Martin Nolte
 *  \brief  interface classes for superentity iterators
 */

namespace Dune
{

  // SuperEntityIterator
  // -------------------

  template< class Grid, template< class > class SuperEntityIteratorImp >
  class SuperEntityIterator
  : public EntityIterator< 0, Grid, SuperEntityIteratorImp< Grid > >
  {
    typedef SuperEntityIterator< Grid, SuperEntityIteratorImp > This;
    typedef EntityIterator< 0, Grid, SuperEntityIteratorImp< Grid > > Base;

    typedef SuperEntityIteratorImp< Grid > Implementation;

  public:
    typedef typename Grid::template Codim< 0 >::Entity Entity;

    SuperEntityIterator ( const Implementation &implementation );

    const This &operator++ ();

    int index () const;

  protected:
    using Base::realIterator;
  };



  // Implementation of SuperEntityIterator
  // -------------------------------------

  template< class Grid, template< class > class SuperEntityIteratorImp >
  inline SuperEntityIterator< Grid, SuperEntityIteratorImp >
    ::SuperEntityIterator ( const Implementation &implementation )
  : Base( implementation )
  {}


  template< class Grid, template< class > class SuperEntityIteratorImp >
  inline const typename SuperEntityIterator< Grid, SuperEntityIteratorImp >::This &
  SuperEntityIterator< Grid, SuperEntityIteratorImp >::operator++ ()
  {
    ++static_cast< Base & >( *this );
    return *this;
  }


  template< class Grid, template< class > class SuperEntityIteratorImp >
  inline int SuperEntityIterator< Grid, SuperEntityIteratorImp >::index () const
  {
    return realIterator.index();
  }



  // Extensions
  // ----------

  /** \brief namespace containing capabilities for extensions */
  namespace Extensions
  {

    /** \brief Does a grid support superentity iterators of a codimension?
     *
     *  \tparam  Grid   grid for which the information is desired
     *  \tparam  codim  codimension in question
     */
    template< class Grid, int codim >
    struct SuperEntityIterator
    {
      /** \brief by default, a grid does not support superentity iterators */
      static const bool v = false;
    };

    template< class Grid, int codim >
    struct SuperEntityIterator< const Grid, codim >
    {
      static const bool v = SuperEntityIterator< Grid, codim >::v;
    };

  }

}

#endif // #ifndef DUNE_GRID_EXTENSIONS_SUPERENTITYITERATOR_HH
