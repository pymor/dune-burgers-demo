/******************************************************************************

  The DUNE (see www.dune-project.org) module dune-spgrid provides a structured,
  parallel grid satisfying the dune-grid interface.

  Copyright (C) 2012 - 2014 Christoph Gersbacher
  Copyright (C) 2010 - 2013 Robert Klöfkorn
  Copyright (C) 2013        Tobias Malkmus
  Copyright (C) 2009 - 2014 Martin Nolte

  The dune-spgrid module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation, either version 2 of 
  the License, or (at your option) any later version.

  The dune-spgrid module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this module. If not, see <http://www.gnu.org/licenses/>.

******************************************************************************/

#ifndef DUNE_SPGRID_PARTITIONLIST_HH
#define DUNE_SPGRID_PARTITIONLIST_HH

#include <dune/grid/spgrid/partition.hh>

namespace Dune
{

  // SPPartitionList
  // ---------------

  template< int dim >
  class SPPartitionList
  {
    typedef SPPartitionList< dim > This;

  protected:
    struct Node;

  public:
    typedef SPPartition< dim > Partition;

    typedef typename Partition::MultiIndex MultiIndex;
    typedef typename Partition::Mesh Mesh;
    
    struct Iterator;

    SPPartitionList ()
    : head_( 0 )
    {}

    SPPartitionList ( const This &other )
    : head_( other.head_ != 0 ? new Node( *other.head_ ) : 0 )
    {}

    ~SPPartitionList ()
    {
      delete head_;
    }

    const This &operator= ( const This &other )
    {
      delete head_;
      head_ = (other.head_ != 0 ? new Node( *other.head_ ) : 0);
      return *this;
    }

    const This &operator+= ( const Partition &partition );

    Iterator begin () const;
    Iterator end () const;

    bool contains ( const MultiIndex &id, const unsigned int number ) const;
    const Partition *findPartition ( const MultiIndex &id ) const;
    int volume () const;

    bool empty () const;
    unsigned int size () const;

  protected:
    Node *head_;
  };



  // SPPartitionList::Node
  // ---------------------

  template< int dim >
  struct SPPartitionList< dim >::Node
  {
    explicit Node ( const Partition &partition )
    : partition_( partition ),
      next_( 0 )
    {}

    Node ( const Node &other )
    : partition_( other.partition_ ),
      next_( other.next_ != 0 ? new Node( *other.next_ ) : 0 )
    {}

    ~Node ()
    {
      delete next_;
    }

    void append ( Node *other )
    {
      if( next_ != 0 )
        next_->append( other );
      else
        next_ = other;
    }

    const Partition &partition () const
    {
      return partition_;
    }

    const Node *next () const
    {
      return next_;
    }

  private:
    Partition partition_;
    Node *next_;
  };



  // SPPartitionList::Iterator
  // -------------------------

  template< int dim >
  struct SPPartitionList< dim >::Iterator
  {
    explicit Iterator ( const Node *node )
    : node_( node )
    {}

    Iterator &operator++ ()
    {
      assert( *this );
      node_ = node_->next();
      return *this;
    }

    operator bool () const
    {
      return bool( node_ );
    }

    bool operator== ( const Iterator &other ) const
    {
      return (node_ == other.node_);
    }

    bool operator!= ( const Iterator &other ) const
    {
      return (node_ != other.node_);
    }

    const Partition &operator* () const
    {
      assert( *this );
      return node_->partition();
    }

    const Partition *operator-> () const
    {
      assert( *this );
      return &(node_->partition());
    }

  private:
    const Node *node_;
  };



  // Implementation of SPPartitionList
  // ---------------------------------

  template< int dim >
  inline const typename SPPartitionList< dim >::This &
  SPPartitionList< dim >::operator+= ( const Partition &partition )
  {
    if( head_ != 0 )
      head_->append( new Node( partition ) );
    else
      head_ = new Node( partition );
    return *this;
  }


  template< int dim >
  inline typename SPPartitionList< dim >::Iterator
  SPPartitionList< dim >::begin () const
  {
    return Iterator( head_ );
  }


  template< int dim >
  inline typename SPPartitionList< dim >::Iterator
  SPPartitionList< dim >::end () const
  {
    return Iterator( 0 );
  }


  template< int dim >
  inline bool
  SPPartitionList< dim >
    ::contains ( const MultiIndex &id, const unsigned int number ) const
  {
    const Partition *partition = findPartition( id );
    assert( !partition || (partition->number() == number) );
    return bool( partition );
  }


  template< int dim >
  inline const typename SPPartitionList< dim >::Partition *
  SPPartitionList< dim >::findPartition ( const MultiIndex &id ) const
  {
    for( const Node *it = head_; it != 0; it = it->next() )
    {
      if( it->partition().contains( id ) )
        return &(it->partition());
    }
    return 0;
  }


  template< int dim >
  inline int SPPartitionList< dim >::volume () const
  {
    int volume = 0;
    for( const Node *it = head_; it != 0; it = it->next() )
      volume += it->partition().volume();
    return volume;
  }


  template< int dim >
  inline bool SPPartitionList< dim >::empty () const
  {
    return (head_ == 0);
  }


  template< int dim >
  inline unsigned int SPPartitionList< dim >::size () const
  {
    unsigned int size = 0;
    for( const Node *it = head_; it != 0; it = it->next() )
      ++size;
    return size;
  }



  // Auxilliary Functions for SPPartitionList
  // ----------------------------------------

  template< class char_type, class traits, int dim >
  inline std::basic_ostream< char_type, traits > &
  operator<< ( std::basic_ostream< char_type, traits > &out,
               const SPPartitionList< dim > &partition )
  {
    typedef typename SPPartitionList< dim >::Iterator Iterator;
    std::string separator = "";
    for( Iterator it = partition.begin(); it; ++it )
    {
      out << separator << *it;
      separator = "; ";
    }
    return out;
  }

} // namespace Dune

#endif // #ifndef DUNE_SPGRID_PARTITIONLIST_HH
