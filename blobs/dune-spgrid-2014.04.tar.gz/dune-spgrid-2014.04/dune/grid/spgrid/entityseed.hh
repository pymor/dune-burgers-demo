/******************************************************************************

  The DUNE (see www.dune-project.org) module dune-spgrid provides a structured,
  parallel grid satisfying the dune-grid interface.

  Copyright (C) 2012 - 2014 Christoph Gersbacher
  Copyright (C) 2010 - 2013 Robert Klöfkorn
  Copyright (C) 2013        Tobias Malkmus
  Copyright (C) 2009 - 2014 Martin Nolte

  The dune-spgrid module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation, either version 2 of 
  the License, or (at your option) any later version.

  The dune-spgrid module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this module. If not, see <http://www.gnu.org/licenses/>.

******************************************************************************/

#ifndef DUNE_SPGRID_ENTITYSEED_HH
#define DUNE_SPGRID_ENTITYSEED_HH

#include <cassert>

#include <dune/common/typetraits.hh>

/** \file
 *  \author Martin Nolte
 *  \brief  entity seed for \ref Dune::SPGrid "SPGrid"
 */

namespace Dune
{

  /** \brief entity seed for \ref Dune::SPGrid "SPGrid"
   *
   *  The entity seed contains the minimal information required to rebuild the
   *  entity, if the grid is still known.
   *  It should be preferred over the entity pointer when storing entities.
   *  
   *  \note While rebuilding an entity pointer from an entity seed is assumed to
   *        be cheap, it introduces non-negligible overhead.
   *        If a large quantity of the grid is to be stored and the order is of
   *        no import, filtering an iterator might be a better option.
   *
   *  \tparam  codim  codimension of the seeded entity
   *  \tparam  Grd    Grid (must be a \ref Dune::SPGrid "SPGrid")
   */
  template< int codim, class Grd >
  struct SPEntitySeed
  {
    /** \brief type of grid this entity seed belongs to */
    typedef typename remove_const< Grd >::type Grid;

    /** \internal \brief type of reference cube */
    typedef typename Grid::Traits::ReferenceCube ReferenceCube;

    /** \brief dimension of the grid */
    static const int dimension = ReferenceCube::dimension;
    /** \brief codimension of the seeded entity */
    static const int codimension = codim;
    /** \brief dimension of the seeded entity */
    static const int mydimension = dimension - codimension;
    /** \brief world dimension of the grid */
    static const int dimensionworld = dimension;

    /** \brief type of the seeded entity */
    typedef typename Grid::Traits::template Codim< codimension >::Entity Entity;

    /** \internal \brief type of multi index */
    typedef typename ReferenceCube::MultiIndex MultiIndex;

    /** \brief default constructor
     *
     *  \note A default constructed entity seed is invalid.
     */
    SPEntitySeed ()
      : level_( -1 )
    {}

    /** \internal
     *  \brief constructor
     *
     *  \param[in]  level            level of the seeded entity
     *  \param[in]  id               multi index of the seeded entity
     *  \param[in]  partitionNumber  number of the partition, the seeded entity
     *                               belongs to
     */
    SPEntitySeed ( const int level, const MultiIndex &id, const unsigned int partitionNumber )
      : level_( level ), id_( id ), partitionNumber_( partitionNumber )
    {}

    /** \brief check whether this seed generates a valid entity */
    bool isValid () const { return (level_ >= 0); }

    /** \internal
     *  \brief obtain level of the seeded entity
     *
     *  \returns the level of the seeded entity
     */
    int level () const
    {
      assert( isValid() );
      return level_;
    }

    /** \internal
     *  \brief obtain the multi index of the seeded entity
     * 
     *  \returns the multi index of the seeded entity
     */
    MultiIndex id () const
    {
      assert( isValid() );
      return id_;
    }

    /** \internal
     *  \brief obtain number of the partition, the seeded entity belongs to
     *
     *  \returns the number of the partition, the seeded entity belongs to
     */
    unsigned int partitionNumber () const
    {
      assert( isValid() );
      return partitionNumber_;
    }

  private:
    int level_;
    MultiIndex id_;
    unsigned int partitionNumber_;
  };

} // namespace Dune

#endif // #ifndef DUNE_SPGRID_ENTITYSEED_HH
