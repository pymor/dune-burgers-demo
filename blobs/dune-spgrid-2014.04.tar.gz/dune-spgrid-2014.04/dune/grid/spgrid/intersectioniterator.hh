/******************************************************************************

  The DUNE (see www.dune-project.org) module dune-spgrid provides a structured,
  parallel grid satisfying the dune-grid interface.

  Copyright (C) 2012 - 2014 Christoph Gersbacher
  Copyright (C) 2010 - 2013 Robert Klöfkorn
  Copyright (C) 2013        Tobias Malkmus
  Copyright (C) 2009 - 2014 Martin Nolte

  The dune-spgrid module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation, either version 2 of 
  the License, or (at your option) any later version.

  The dune-spgrid module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this module. If not, see <http://www.gnu.org/licenses/>.

******************************************************************************/

#ifndef DUNE_SPGRID_INTERSECTIONITERATOR_HH
#define DUNE_SPGRID_INTERSECTIONITERATOR_HH

#include <dune/grid/spgrid/intersection.hh>

#include <dune/grid/common/intersectioniterator.hh>

namespace Dune
{

  template< class Grid >
  class SPIntersectionIterator
  {
    typedef SPIntersectionIterator< Grid > This;

    typedef typename remove_const< Grid >::type::Traits Traits;

    typedef SPIntersection< Grid > IntersectionImpl;

  public:
    typedef Dune::Intersection< Grid, IntersectionImpl > Intersection;

    typedef typename Intersection::Entity Entity;
    
    typedef typename IntersectionImpl::EntityInfo EntityInfo;
    typedef typename IntersectionImpl::GridLevel GridLevel;

    SPIntersectionIterator ( const EntityInfo &entityInfo, const int face )
    : intersection_( IntersectionImpl( entityInfo, face ) )
    {}

    SPIntersectionIterator ( const This &other )
    : intersection_( Grid::getRealImplementation( other.intersection_ ) )
    {}

    const This &operator= ( const This &other )
    {
      Grid::getRealImplementation( intersection_ ) = Grid::getRealImplementation( other.intersection_ );
      return *this;
    }

    const Intersection &dereference () const
    {
      return intersection_;
    }

    bool equals ( const This &other ) const
    {
      return Grid::getRealImplementation( intersection_ ).equals( Grid::getRealImplementation( other.intersection_ ) );
    }

    void increment ()
    {
      const int face = intersection_.indexInInside();
      assert( face < GridLevel::ReferenceCube::numFaces );
      Grid::getRealImplementation( intersection_ ).setFace( face+1 );
    }

  private:
    Intersection intersection_;
  };

} // namespace Dune

#endif // #ifndef DUNE_SPGRID_INTERSECTIONITERATOR_HH
