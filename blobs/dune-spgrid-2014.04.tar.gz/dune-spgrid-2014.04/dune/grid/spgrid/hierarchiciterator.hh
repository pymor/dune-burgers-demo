/******************************************************************************

  The DUNE (see www.dune-project.org) module dune-spgrid provides a structured,
  parallel grid satisfying the dune-grid interface.

  Copyright (C) 2012 - 2014 Christoph Gersbacher
  Copyright (C) 2010 - 2013 Robert Klöfkorn
  Copyright (C) 2013        Tobias Malkmus
  Copyright (C) 2009 - 2014 Martin Nolte

  The dune-spgrid module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation, either version 2 of 
  the License, or (at your option) any later version.

  The dune-spgrid module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this module. If not, see <http://www.gnu.org/licenses/>.

******************************************************************************/

#ifndef DUNE_SPGRID_HITERATOR_HH
#define DUNE_SPGRID_HITERATOR_HH

#include <dune/grid/common/entityiterator.hh>

#include <dune/grid/spgrid/entitypointer.hh>

namespace Dune
{

  template< class Grid >
  class SPHierarchicIterator
  : public SPEntityPointer< 0, Grid >
  {
    typedef SPHierarchicIterator< Grid > This;
    typedef SPEntityPointer< 0, Grid > Base;

    friend class SPEntity< 0, Base::dimension, Grid >;

  public:
    typedef typename Base::Entity Entity;
    typedef typename Base::EntityInfo EntityInfo;

  protected:
    typedef typename Base::EntityImpl EntityImpl;

  private:
    SPHierarchicIterator ( const EntityImpl &entityImpl, int maxLevel )
    : Base( entityImpl ),
      minLevel_( entityImpl.level() ),
      maxLevel_( std::min( maxLevel, entityImpl.grid().maxLevel() ) )
    {
      increment();
    }

  public:
    using Base::level;
    using Base::dereference;

    void increment ()
    {
      EntityInfo &entityInfo = Grid::getRealImplementation( entity_ ).entityInfo();
      if( level() >= maxLevel_ )
      {
        while( (level() > minLevel_) && !entityInfo.nextChild() )
          entityInfo.up();
      }
      else
        entityInfo.down();
      entityInfo.update();
    }

  protected:
    using Base::entity_;

  private:
    int minLevel_, maxLevel_;
  };

} // namespace Dune

#endif // #ifndef DUNE_SPGRID_HITERATOR_HH
