/******************************************************************************

  The DUNE (see www.dune-project.org) module dune-spgrid provides a structured,
  parallel grid satisfying the dune-grid interface.

  Copyright (C) 2012 - 2014 Christoph Gersbacher
  Copyright (C) 2010 - 2013 Robert Klöfkorn
  Copyright (C) 2013        Tobias Malkmus
  Copyright (C) 2009 - 2014 Martin Nolte

  The dune-spgrid module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation, either version 2 of 
  the License, or (at your option) any later version.

  The dune-spgrid module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this module. If not, see <http://www.gnu.org/licenses/>.

******************************************************************************/

#ifndef DUNE_SPGRID_ITERATOR_HH
#define DUNE_SPGRID_ITERATOR_HH

#include <dune/grid/spgrid/misc.hh>
#include <dune/grid/spgrid/entitypointer.hh>

namespace Dune
{

  // SPPartitionIterator
  // -------------------

  template< int codim, class Grid >
  class SPPartitionIterator
  : public SPEntityPointer< codim, Grid >
  {
    typedef SPPartitionIterator< codim, Grid > This;
    typedef SPEntityPointer< codim, Grid > Base;

  public:
    typedef typename Base::EntityInfo EntityInfo;
    typedef typename Base::GridLevel GridLevel;

    static const int dimension = Base::dimension;
    static const int codimension = Base::codimension;
    static const int mydimension = Base::mydimension;

    typedef SPPartitionList< dimension > PartitionList;

    static const unsigned int numDirections = GridLevel::numDirections;

    struct Begin {};
    struct End {};

  protected:
    typedef typename EntityInfo::MultiIndex MultiIndex;

  public:
    using Base::gridLevel;

    SPPartitionIterator ( const GridLevel &gridLevel, const PartitionList &partitionList,
                          const Begin &b, const unsigned int sweepDir = 0 );
    SPPartitionIterator ( const GridLevel &gridLevel, const PartitionList &partitionList,
                          const End &e, const unsigned int sweepDir = 0 );

    operator bool () const { return bool( partition_ ); }
    This &operator++ ();

    void increment ();

  private:
    int begin ( const int i, const unsigned int dir ) const;
    int end ( const int i, const unsigned int dir ) const;

    void init ();

  protected:
    using Base::entity_;

  private:
    typename PartitionList::Iterator partition_;
    unsigned int sweepDirection_;
  };



  // Implementation of SPPartitionIterator
  // -------------------------------------

  template< int codim, class Grid >
  inline SPPartitionIterator< codim, Grid >
    ::SPPartitionIterator ( const GridLevel &gridLevel, const PartitionList &partitionList,
                            const Begin &b, const unsigned int sweepDir )
  : Base( gridLevel ),
    partition_( partitionList.begin() ),
    sweepDirection_( sweepDir )
  {
    assert( sweepDir < numDirections );
    init();
  }


  template< int codim, class Grid >
  inline SPPartitionIterator< codim, Grid >
    ::SPPartitionIterator ( const GridLevel &gridLevel, const PartitionList &partitionList,
                            const End &e, const unsigned int sweepDir )
  : Base( gridLevel ),
    partition_( partitionList.end() ),
    sweepDirection_( sweepDir )
  {
    assert( sweepDir < numDirections );
    init();
  }


  template< int codim, class Grid >
  inline typename SPPartitionIterator< codim, Grid >::This &
  SPPartitionIterator< codim, Grid >::operator++ ()
  {
    increment();
    return *this;
  }


  template< int codim, class Grid >
  inline void SPPartitionIterator< codim, Grid >::increment ()
  {
    EntityInfo &entityInfo = Grid::getRealImplementation( entity_ ).entityInfo();
    MultiIndex &id = entityInfo.id();
    for( int i = 0; i < dimension; ++i )
    {
      const unsigned int sweep = (sweepDirection_ >> i) & 1;
      id[ i ] += (2 - 4*sweep);
      if( id[ i ] != end( i, entityInfo.direction() ) )
        return entityInfo.update();
      id[ i ] = begin( i, entityInfo.direction() );
    }

    unsigned int dir = entityInfo.direction()+1;
    const unsigned int mydim = mydimension;
    for( ; (dir < numDirections) && ((bitCount( dir ) != mydim) || partition_->empty( dir )); ++dir );
    if( dir < numDirections )
    {
      for( int i = 0; i < dimension; ++i )
        id[ i ] = begin( i, dir );
      entityInfo.update();
    }
    else
    {
      ++partition_;
      init();
    }
  }


  template< int codim, class Grid >
  inline int
  SPPartitionIterator< codim, Grid >::begin ( const int i, const unsigned int dir ) const
  {
    const unsigned int s = (sweepDirection_ >> i) & 1;
    const unsigned int d = (dir >> i) & 1;
    return partition_->bound( s, i, d );
  }


  template< int codim, class Grid >
  inline int
  SPPartitionIterator< codim, Grid >::end ( const int i, const unsigned int dir ) const
  {
    const unsigned int s = (sweepDirection_ >> i) & 1;
    const unsigned int d = (dir >> i) & 1;
    const int bnd = partition_->bound( 1-s, i, d );
    return bnd + 2*(2*(1-s) - 1);
  }


  template< int codim, class Grid >
  inline void
  SPPartitionIterator< codim, Grid >::init ()
  {
    EntityInfo &entityInfo = Grid::getRealImplementation( entity_ ).entityInfo();
    MultiIndex &id = entityInfo.id();
    if( partition_ )
    {
      unsigned int dir = 0;
      const unsigned int mydim = mydimension;
      for( ; (dir < numDirections) && ((bitCount( dir ) != mydim) || partition_->empty( dir )); ++dir );
      if( dir < numDirections )
      {
        for( int i = 0; i < dimension; ++i )
          id[ i ] = begin( i, dir );
        entityInfo.update( partition_->number() );
      }
      else
      {
        ++partition_;
        init();
      }
    }
    else
      id = std::numeric_limits< MultiIndex >::max();
  }



  // SPIterator
  // ----------

  template< int codim, PartitionIteratorType pitype, class Grid >
  class SPIterator
  : public SPPartitionIterator< codim, Grid >
  {
    typedef SPIterator< codim, pitype, Grid > This;
    typedef SPPartitionIterator< codim, Grid > Base;

  public:
    typedef typename Base::GridLevel GridLevel;

    template< class BeginEnd >
    SPIterator ( const GridLevel &gridLevel, const BeginEnd &be, const unsigned int sweepDir = 0 )
    : Base( gridLevel, gridLevel.template partition< pitype >(), be, sweepDir )
    {}
  };

} // namespace Dune

#endif // #ifndef DUNE_SPGRID_ITERATOR_HH
