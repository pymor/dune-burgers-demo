/******************************************************************************

  The DUNE (see www.dune-project.org) module dune-spgrid provides a structured,
  parallel grid satisfying the dune-grid interface.

  Copyright (C) 2012 - 2014 Christoph Gersbacher
  Copyright (C) 2010 - 2013 Robert Klöfkorn
  Copyright (C) 2013        Tobias Malkmus
  Copyright (C) 2009 - 2014 Martin Nolte

  The dune-spgrid module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation, either version 2 of 
  the License, or (at your option) any later version.

  The dune-spgrid module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this module. If not, see <http://www.gnu.org/licenses/>.

******************************************************************************/

#ifndef DUNE_SPGRID_ENTITYINFO_HH
#define DUNE_SPGRID_ENTITYINFO_HH

#include <limits>

#include <dune/common/typetraits.hh>

#include <dune/grid/common/gridenums.hh>

#include <dune/grid/spgrid/gridlevel.hh>

namespace Dune
{

  // SPBasicEntityInfo
  // -----------------

  template< class Grid, int dim, int codim >
  class SPBasicEntityInfo
  {
    typedef SPBasicEntityInfo< Grid, dim, codim > This;

  public:
    typedef SPGridLevel< typename remove_const< Grid >::type > GridLevel;

    static const int dimension = GridLevel::dimension;

    typedef typename GridLevel::MultiIndex MultiIndex;
    typedef typename GridLevel::GlobalVector GlobalVector;

    SPBasicEntityInfo ( const GridLevel &gridLevel )
    : gridLevel_( &gridLevel )
    {}

    SPBasicEntityInfo ( const GridLevel &gridLevel, const MultiIndex &id )
    : gridLevel_( &gridLevel ),
      id_( id ),
      direction_( id.direction() )
    {}

    unsigned int direction () const
    {
      return direction_;
    }

    const MultiIndex &id () const
    {
      return id_;
    }

    MultiIndex &id ()
    {
      return id_;
    }

    const GridLevel &gridLevel () const
    {
      return *gridLevel_;
    }

    void update ()
    {
      direction_ = id_.direction();
    }

  private:
    const GridLevel *gridLevel_;
    MultiIndex id_;
    unsigned int direction_;
  };



  // SPBasicEntityInfo (for codim =  0)
  // ----------------------------------

  template< class Grid, int dim >
  class SPBasicEntityInfo< Grid, dim, 0 >
  {
    typedef SPBasicEntityInfo< Grid, dim, 0 > This;

  public:
    typedef SPGridLevel< typename remove_const< Grid >::type > GridLevel;

    static const int dimension = GridLevel::dimension;

    typedef typename GridLevel::MultiIndex MultiIndex;
    typedef typename GridLevel::GlobalVector GlobalVector;

    SPBasicEntityInfo ( const GridLevel &gridLevel )
    : gridLevel_( &gridLevel )
    {}

    SPBasicEntityInfo ( const GridLevel &gridLevel, const MultiIndex &id )
    : gridLevel_( &gridLevel ),
      id_( id )
    {}

    unsigned int direction () const
    {
      return (1 << dimension) - 1;
    }

    const MultiIndex &id () const
    {
      return id_;
    }

    MultiIndex &id ()
    {
      return id_;
    }

    const GridLevel &gridLevel () const
    {
      return *gridLevel_;
    }

    void update ()
    {
      assert( (id_.direction() == direction()) );
    }

    void down ()
    {
      const Grid &grid = gridLevel().grid();
      const int level = gridLevel().level();
      gridLevel_ = &grid.gridLevel( level+1 );
      gridLevel().refinement().firstChild( id_ );
    }

    void up ()
    {
      const Grid &grid = gridLevel().grid();
      const int level = gridLevel().level();
      gridLevel().refinement().father( id_ );
      gridLevel_ = &grid.gridLevel( level-1 );
    }

    bool nextChild ()
    {
      return gridLevel().refinement().nextChild( id_ );
    }

  private:
    const GridLevel *gridLevel_;
    MultiIndex id_;
  };



  // SPBasicEntityInfo (for codim = dim)
  // -----------------------------------

  template< class Grid, int dim >
  class SPBasicEntityInfo< Grid, dim, dim >
  {
    typedef SPBasicEntityInfo< Grid, dim, dim > This;

  public:
    typedef SPGridLevel< typename remove_const< Grid >::type > GridLevel;

    typedef typename GridLevel::MultiIndex MultiIndex;
    typedef typename GridLevel::GlobalVector GlobalVector;

    SPBasicEntityInfo ( const GridLevel &gridLevel )
    : gridLevel_( &gridLevel )
    {}

    SPBasicEntityInfo ( const GridLevel &gridLevel, const MultiIndex &id )
    : gridLevel_( &gridLevel ),
      id_( id )
    {}

    unsigned int direction () const
    {
      return 0;
    }

    const MultiIndex &id () const
    {
      return id_;
    }

    MultiIndex &id ()
    {
      return id_;
    }

    const GridLevel &gridLevel () const
    {
      return *gridLevel_;
    }

    void update ()
    {
      assert( (id_.direction() == direction()) );
    }

  private:
    const GridLevel *gridLevel_;
    MultiIndex id_;
  };



  // SPEntityInfo
  // ------------

  template< class Grid, int codim >
  class SPEntityInfo
  : public SPBasicEntityInfo< Grid, remove_const< Grid >::type::dimension, codim >
  {
    typedef SPEntityInfo< Grid, codim > This;
    typedef SPBasicEntityInfo< Grid, remove_const< Grid >::type::dimension, codim > Base;

  public:
    typedef typename Base::GridLevel GridLevel;

    typedef typename GridLevel::Traits Traits;
    typedef typename GridLevel::ctype ctype;

    static const int dimension = GridLevel::dimension;
    static const int codimension = codim;
    static const int mydimension = dimension - codimension;
    
    typedef typename GridLevel::MultiIndex MultiIndex;
    typedef typename GridLevel::GlobalVector GlobalVector;

    typedef typename GridLevel::template Codim< codim >::GeometryCache GeometryCache;
    typedef typename GeometryCache::LocalVector LocalVector;

    SPEntityInfo ( const GridLevel &gridLevel )
    : Base( gridLevel ),
      partitionNumber_( std::numeric_limits< unsigned int >::max() )
    {}

    SPEntityInfo ( const GridLevel &gridLevel, const MultiIndex &id,
                   const unsigned int partitionNumber )
    : Base( gridLevel, id ),
      partitionNumber_( partitionNumber )
    {}

    using Base::direction;
    using Base::id;
    using Base::gridLevel;

    bool equals ( const This &other ) const
    {
      return (&gridLevel() == &other.gridLevel()) && (id() == other.id());
    }

    unsigned int partitionNumber () const
    {
      return partitionNumber_;
    }

    PartitionType partitionType () const
    {
      return gridLevel().template partitionType< codim >( id(), partitionNumber() );
    }

    const GeometryCache &geometryCache () const
    {
      return gridLevel().template geometryCache< codim >( direction() );
    }

    void update ()
    {
      assert( id() != std::numeric_limits< MultiIndex >::max() );
      assert( gridLevel().template partition< All_Partition >().contains( id(), partitionNumber() ) );
      Base::update();
    }

    void update ( const unsigned int partitionNumber )
    {
      partitionNumber_ = partitionNumber;
      update();
    }

  private:
    unsigned int partitionNumber_;
  };

} // namespace Dune

#endif // #ifndef DUNE_SPGRID_ENTITYINFO_HH
