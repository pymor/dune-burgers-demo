/******************************************************************************

  The DUNE (see www.dune-project.org) module dune-spgrid provides a structured,
  parallel grid satisfying the dune-grid interface.

  Copyright (C) 2012 - 2014 Christoph Gersbacher
  Copyright (C) 2010 - 2013 Robert Klöfkorn
  Copyright (C) 2013        Tobias Malkmus
  Copyright (C) 2009 - 2014 Martin Nolte

  The dune-spgrid module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation, either version 2 of 
  the License, or (at your option) any later version.

  The dune-spgrid module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this module. If not, see <http://www.gnu.org/licenses/>.

******************************************************************************/

#ifndef DUNE_SPGRID_HINDEXSET_HH
#define DUNE_SPGRID_HINDEXSET_HH

#include <vector>

#include <dune/common/array.hh>

#include <dune/grid/spgrid/indexset.hh>

namespace Dune
{

  // SPHierarchyIndexSet
  // -------------------

  template< class Grid >
  class SPHierarchyIndexSet
  : public IndexSet< Grid, SPHierarchyIndexSet< Grid >, unsigned int >
  {
    typedef SPHierarchyIndexSet< Grid > This;
    typedef IndexSet< Grid, This, unsigned int > Base;

    typedef typename remove_const< Grid >::type::Traits Traits;

  public:
    typedef typename Base::IndexType IndexType;

    static const int dimension = Traits::ReferenceCube::dimension;

    template< int codim >
    struct Codim
    {
      typedef SPEntityInfo< Grid, codim > EntityInfo;
      typedef typename Traits::template Codim< codim >::Entity Entity;
    };

    typedef SPGridLevel< typename remove_const< Grid >::type > GridLevel;

  private:
    typedef SPIndexSet< Grid > LevelIndexSet;

    typedef array< IndexType, dimension+1 > CodimIndexArray;

  public:
    explicit SPHierarchyIndexSet ( const Grid &grid )
    : grid_( &grid )
    {
      for( int codim = 0; codim <= dimension; ++codim )
        size_[ codim ] = 0;
    }

    void update ()
    {
      for( int codim = 0; codim <= dimension; ++codim )
        size_[ codim ] = 0;

      const int maxLevel = grid().maxLevel();
      levelIndexSets_.resize( maxLevel+1 );
      offsets_.resize( maxLevel+1 );
      for( int level = 0; level <= maxLevel; ++level )
      {
        const LevelIndexSet &levelIndexSet = grid().levelIndexSet( level );
        levelIndexSets_[ level ] = &levelIndexSet;
        for( int codim = 0; codim <= dimension; ++codim )
        {
          offsets_[ level ][ codim ] = size_[ codim ];
          size_[ codim ] += levelIndexSet.size( codim );
        }
      }
    }

    template< class Entity >
    IndexType index ( const Entity &entity ) const
    {
      return index< Entity::codimension >( entity );
    }

    template< int codim >
    IndexType index ( const typename Codim< codim >::Entity &entity ) const
    {
      const int level = entity.level();
      const IndexType offset = offsets_[ level ][ codim ];
      return offset + levelIndexSet( level ).index( entity );
    }

    template< int codim >
    IndexType DUNE_DEPRECATED
    subIndex ( const typename Codim< 0 >::Entity &entity, const int i ) const
    {
      DUNE_THROW( NotImplemented, "SPHierarchyIndexSet does not implement the old subIndex method." );
    }

    IndexType subIndex ( const typename Codim< 0 >::Entity &entity,
                         const int i, const unsigned int codim ) const
    {
      const int level = entity.level();
      const IndexType offset = offsets_[ level ][ codim ];
      return offset + levelIndexSet( level ).subIndex( entity, i, codim );
    }

    const std::vector< GeometryType > &geomTypes ( const int codim ) const
    {
      return levelIndexSet( 0 ).geomTypes( codim );
    }

    IndexType size ( const GeometryType &type ) const
    {
      return (type.isCube() ? size( dimension - type.dim() ) : 0);
    }

    IndexType size ( const int codim ) const
    {
      assert( (codim >= 0) && (codim <= dimension) );
      return size_[ codim ];
    }

    template< class Entity >
    bool contains ( const Entity &entity ) const
    {
      return contains< Entity::codimension >( entity );
    }

    template< int codim >
    bool contains ( const typename Codim< codim >::Entity &entity ) const
    {
      return true;
    }

    const Grid &grid () const
    {
      return *grid_;
    }

    const LevelIndexSet &levelIndexSet ( const int level ) const
    {
      assert( (level >= 0) && (level <= (int)levelIndexSets_.size()) );
      assert( (int)levelIndexSets_.size() == grid().maxLevel()+1 );
      return *levelIndexSets_[ level ];
    }

  private:
    const Grid *grid_;
    std::vector< const LevelIndexSet * > levelIndexSets_;
    std::vector< CodimIndexArray > offsets_;
    CodimIndexArray size_;
  };

} // namespace Dune

#endif // #ifndef DUNE_SPGRID_HINDEXSET_HH
