/******************************************************************************

  The DUNE (see www.dune-project.org) module dune-spgrid provides a structured,
  parallel grid satisfying the dune-grid interface.

  Copyright (C) 2012 - 2014 Christoph Gersbacher
  Copyright (C) 2010 - 2013 Robert Klöfkorn
  Copyright (C) 2013        Tobias Malkmus
  Copyright (C) 2009 - 2014 Martin Nolte

  The dune-spgrid module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation, either version 2 of 
  the License, or (at your option) any later version.

  The dune-spgrid module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this module. If not, see <http://www.gnu.org/licenses/>.

******************************************************************************/

#ifndef DUNE_SPGRID_GEOMETRICGRIDLEVEL_HH
#define DUNE_SPGRID_GEOMETRICGRIDLEVEL_HH

#include <cassert>

#include <dune/common/forloop.hh>

#include <dune/grid/spgrid/referencecube.hh>
#include <dune/grid/spgrid/geometrycache.hh>

namespace Dune
{

  // SPGeometricGridLevel
  // --------------------

  template< class ct, int dim >
  class SPGeometricGridLevel
  {
    typedef SPGeometricGridLevel< ct, dim > This;

  public:
    typedef SPReferenceCubeContainer< ct, dim > ReferenceCubeContainer;

    typedef typename ReferenceCubeContainer::ReferenceCube ReferenceCube;

    typedef typename ReferenceCube::ctype ctype;
    static const int dimension = ReferenceCube::dimension;

    typedef typename ReferenceCube::GlobalVector GlobalVector;

    static const unsigned int numDirections = ReferenceCube::numCorners;

    template< int codim >
    struct Codim
    {
      typedef typename ReferenceCubeContainer::template Codim< codim >::ReferenceCube ReferenceCube;
      typedef SPGeometryCache< ctype, dimension, codim > GeometryCache;
    };

  private:
    template< int codim >
    struct BuildGeometryCache;
    template< int codim >
    struct DestroyGeometryCache;

  public:
    SPGeometricGridLevel ( const ReferenceCubeContainer &refCubes, const GlobalVector &h );
    SPGeometricGridLevel ( const This &other );

    ~SPGeometricGridLevel ();

    const ReferenceCube &referenceCube () const { return refCubes_.get(); }

    template< int codim >
    const typename Codim< codim >::ReferenceCube &
    referenceCube () const { return refCubes_.template get< codim >(); }

    const GlobalVector &h () const { return h_; }

    template< int codim >
    const typename Codim< codim >::GeometryCache &
    geometryCache ( const unsigned int dir ) const;

    ctype faceVolume ( const int i ) const;
    const GlobalVector &volumeNormal ( const int i ) const;

  private:
    void buildGeometry ();

    const ReferenceCubeContainer &refCubes_;

    GlobalVector h_;
    void *geometryCache_[ numDirections ];
    ctype faceVolume_[ ReferenceCube::numFaces ];
    GlobalVector normal_[ ReferenceCube::numFaces ];
  };



  // SPGeometricGridLevel::BuildGeometryCache
  // ----------------------------------------

  template< class ct, int dim >
  template< int codim >
  struct SPGeometricGridLevel< ct, dim >::BuildGeometryCache
  {
    static void
    apply ( const GlobalVector &h, void *(&geometryCache)[ 1 << dimension ] )
    {
      typedef typename Codim< codim >::GeometryCache GeometryCache;
      for( unsigned int dir = 0; dir < (1 << dimension); ++dir )
      {
        const int mydim = bitCount( dir );
        if( mydim == dimension - codim )
          geometryCache[ dir ] = new GeometryCache( h, dir );
      }
    }
  };



  // SPGeometricGridLevel::DestroyGeometryCache
  // ------------------------------------------

  template< class ct, int dim >
  template< int codim >
  struct SPGeometricGridLevel< ct, dim >::DestroyGeometryCache
  {
    static void
    apply ( void *(&geometryCache)[ 1 << dimension ] )
    {
      typedef typename Codim< codim >::GeometryCache GeometryCache;
      for( unsigned int dir = 0; dir < (1 << dimension); ++dir )
      {
        const int mydim = bitCount( dir );
        if( mydim == dimension - codim )
        {
          delete (GeometryCache *)geometryCache[ dir ];
          geometryCache[ dir ] = 0;
        }
      }
    }
  };



  // Implementation of SPGeometricGridLevel
  // --------------------------------------

  template< class ct, int dim >
  inline SPGeometricGridLevel< ct, dim >
    ::SPGeometricGridLevel ( const ReferenceCubeContainer &refCubes, const GlobalVector &h )
  : refCubes_( refCubes ),
    h_( h )
  {
    buildGeometry();
  }


  template< class ct, int dim >
  inline SPGeometricGridLevel< ct, dim >::SPGeometricGridLevel ( const This &other )
  : refCubes_( other.refCubes_ ),
    h_( other.h_ )
  {
    buildGeometry();
  }


  template< class ct, int dim >
  inline SPGeometricGridLevel< ct, dim >::~SPGeometricGridLevel ()
  {
    ForLoop< DestroyGeometryCache, 0, dimension >::apply( geometryCache_ );
  }


  template< class ct, int dim >
  template< int codim >
  inline const typename SPGeometricGridLevel< ct, dim >::template Codim< codim >::GeometryCache &
  SPGeometricGridLevel< ct, dim >::geometryCache ( const unsigned int dir ) const
  {
    typedef typename Codim< codim >::GeometryCache GeometryCache;
    assert( bitCount( dir ) == dimension - codim );
    return *((const GeometryCache *)geometryCache_[ dir ]);
  }


  template< class ct, int dim >
  inline typename SPGeometricGridLevel< ct, dim >::ctype
  SPGeometricGridLevel< ct, dim >::faceVolume ( const int i ) const
  {
    assert( (i >= 0) && (i < ReferenceCube::numFaces) );
    return faceVolume_[ i ];
  }


  template< class ct, int dim >
  inline const typename SPGeometricGridLevel< ct, dim >::GlobalVector &
  SPGeometricGridLevel< ct, dim >::volumeNormal ( const int i ) const
  {
    assert( (i >= 0) && (i < ReferenceCube::numFaces) );
    return normal_[ i ];
  }


  template< class ct, int dim >
  inline void SPGeometricGridLevel< ct, dim >::buildGeometry ()
  {
    ForLoop< BuildGeometryCache, 0, dimension >::apply( h_, geometryCache_ );
    
    const ctype volume = geometryCache< 0 >( numDirections-1 ).volume();
    for( int face = 0; face < ReferenceCube::numFaces; ++face )
    {
      normal_[ face ] = referenceCube().normal( face );
      faceVolume_[ face ] = std::abs( volume / (normal_[ face ] * h_) );
      normal_[ face ] *= faceVolume_[ face ];
    }
  }

} // namespace Dune

#endif // #ifndef DUNE_SPGRID_GEOMETRICGRIDLEVEL_HH
