/******************************************************************************

  The DUNE (see www.dune-project.org) module dune-spgrid provides a structured,
  parallel grid satisfying the dune-grid interface.

  Copyright (C) 2012 - 2014 Christoph Gersbacher
  Copyright (C) 2010 - 2013 Robert Klöfkorn
  Copyright (C) 2013        Tobias Malkmus
  Copyright (C) 2009 - 2014 Martin Nolte

  The dune-spgrid module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation, either version 2 of 
  the License, or (at your option) any later version.

  The dune-spgrid module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this module. If not, see <http://www.gnu.org/licenses/>.

******************************************************************************/

#ifndef DUNE_SPGRID_VERSION_HH
#define DUNE_SPGRID_VERSION_HH

namespace Dune
{

  struct SPGridVersion
  {
    static const unsigned int major = 2014;
    static const unsigned int minor = 4;

    static bool later ( const unsigned int vMajor, const unsigned int vMinor )
    {
      return (vMajor > major) || ((vMajor == major) && (vMinor > minor));
    }
  };

} // namespace Dune

#endif // #ifndef DUNE_SPGRID_VERSION_HH
