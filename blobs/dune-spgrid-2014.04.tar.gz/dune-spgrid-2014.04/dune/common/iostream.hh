/******************************************************************************

  The DUNE (see www.dune-project.org) module dune-spgrid provides a structured,
  parallel grid satisfying the dune-grid interface.

  Copyright (C) 2012 - 2014 Christoph Gersbacher
  Copyright (C) 2010 - 2013 Robert Klöfkorn
  Copyright (C) 2013        Tobias Malkmus
  Copyright (C) 2009 - 2014 Martin Nolte

  The dune-spgrid module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation, either version 2 of 
  the License, or (at your option) any later version.

  The dune-spgrid module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this module. If not, see <http://www.gnu.org/licenses/>.

******************************************************************************/

#ifndef DUNE_COMMON_IOSTREAM_HH
#define DUNE_COMMON_IOSTREAM_HH

#include <iostream>

namespace Dune
{

  namespace iostream
  {

    template< class T >
    struct MatchTraits
    {
      typedef T Type;
    };

    template< class T >
    struct MatchTraits< const T >
    {
      typedef const typename MatchTraits< T >::Type Type;
    };

    template< int n >
    struct MatchTraits< char[ n ] >
    {
      typedef std::string Type;
    };


    template< class T >
    struct Match
    {
      explicit Match ( const T &value )
      : value_( value )
      {}

      template< class U >
      Match ( const Match< U > &other )
      : value_( other.value_ )
      {}

      bool operator() ( const T &value ) const
      {
        return (value_ == value);
      }

    private:
      T value_;
    };

  }


  template< class char_type, class traits >
  inline bool isGood ( std::basic_istream< char_type, traits > &in )
  {
    bool good = in.good();
    if( good )
    {
      char_type c;
      in >> c;
      good = !in.fail();
      if( good )
        in.unget();
      in.clear();
    }
    return good;
  }


  template< class T >
  inline iostream::Match< typename iostream::MatchTraits< T >::Type >
  match ( const T &value )
  {
    return iostream::Match< typename iostream::MatchTraits< T >::Type >( value );
  }


  template< class char_type, class traits, class T >
  inline std::basic_istream< char_type, traits > &
  operator>> ( std::basic_istream< char_type, traits > &in, const iostream::Match< T > &match )
  {
    T value;
    in >> value;
    if( !match( value ) )
      in.clear( std::ios_base::failbit );
    return in;
  }

}

#endif // #ifndef DUNE_COMMON_IOSTREAM_HH
